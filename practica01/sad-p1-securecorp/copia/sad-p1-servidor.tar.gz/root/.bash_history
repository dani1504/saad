/etc/ldif/tls
cd /etc/ldif/tls
cd /etc/ldif/
cd /etc/ldif
cd /ldif
ls
nano 03-tls.ldif 
nano 02-tu-turno.ldif 
exit
service slapd start
mkdir -p /etc/ldap/tls
cp /pki/ca/ca.crt /pki/servidor/ldap.crt /pki/servidor/ldap.key /etc/ldap/tls/
chown -R openldap:openldap /etc/ldap/tls
chmod 755 /etc/ldap/tls
chmod 644 /etc/ldap/tls/ca.crt /etc/ldap/tls/ldap.crt
chmod 600 /etc/ldap/tls/ldap.key
ldapmodify -Y EXTERNAL -H ldapi:/// -f /ldif/03-tls.ldif
cd /ldif
ldapadd -c -x -H ldapi:/// -D "cn=admin,dc=securecorp,dc=local" -w SecureCorp2026 -f 01-ejemplo.ldif
ldapadd -c -x -H ldapi:/// -D "cn=admin,dc=securecorp,dc=local" -w SecureCorp2026 -f 02-tu-turno.ldif
ldappasswd -x -H ldapi:/// -D "cn=admin,dc=securecorp,dc=local" -w SecureCorp2026 -s 'Lucia2026' "uid=lromero,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldapi:/// -D "cn=admin,dc=securecorp,dc=local" -w SecureCorp2026 -s 'Daniel2026' "uid=dgonzalez,ou=people,dc=securecorp,dc=local"
[200~ldappasswd -x -H ldapi:/// -D "cn=admin,dc=securecorp,dc=local" -w SecureCorp2026 -s 'Marta2026' "uid=mtorres,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldapi:/// -D "cn=admin,dc=securecorp,dc=local" -w SecureCorp2026 -s 'Marta2026' "uid=mtorres,ou=people,dc=securecorp,dc=local"
/etc/default/slapd
cd /etc/default/slapd
nano /etc/default/slapd
exit
/etc/ldap/ldap.conf
nano /etc/ldap/ldap.conf
exit
exit
kdb5_util create -s -r SECURECORP.LOCAL
service krb5-kdc start
exit
kadmin.local -q "addprinc lromero"
kadmin.local -q "addprinc lromero"
kadmin.local -q "addprinc -randkey host/web.securecorp.local"
kadmin.local -q "listprincs"
exit
kadmin.local -q "addprinc dgonzalez"
kadmin.local -q "addprinc mtorres"
kadmin.local -q "addprinc mtorres"
kadmin.local -q "addprinc mtorres"
exit
kadmin.local -q "?"
exit
kadmin.local -q "addprinc manuel"
klist
kadmin.local -q "listprincs"
kinit
kinit manuel
klist
exit
kdestroy manuel
kdestroy
klisty
klist
kadmin.local -q "listprincs"
exit
exit
kadmin.local -q "modprinc -allow_tix mtorres"
kinit mtorres
exit
openssl x509 -in ca.crt -noout -issuer
openssl x509 -in ca.crt -noout -subject -issuer
exit
openssl x509 -in ca.crt -noout -dates
openssl x509 -in /pki/ca/ca.crt -noout -subject -issuer
openssl x509 -in /pki/ca/ca.crt -noout -dates
nano /ldif/
nano /ldif/03-tls.ldif 
exit
ls
cd /ldif
ls
cd ..
exit
cd ldif
cd /ldif
ls
nano 02-tu-turno.ldif 
exit
ldapadd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif
cd /ldif/
ldapadd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldapadd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldapadd -x -i -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldapadd -x -c -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldapadd -x -c -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -s 'Elena2026' "uid=eleon,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -s 'Elena2026' "uid=eleon,ou=people,dc=securecorp,dc=local"
ldapwhoami -x -H ldap://ldap.securecorp.local -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=eleon,ou=people,dc=securecorp,dc=local" -w 'Elena2026'
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(cn=sistemas)" uid
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(cn=sistemas)" uid
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(cn=sistemas)" uid
exit
exit
cd /ldif/
ls
nano 02-tu-turno.ldif 
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(cn=sistemas)" uid
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "()" uid
exit
nano 02-tu-turno.ldif 
cd /ldif/
nano 02-tu-turno.ldif 
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(cn=sistemas)" uid
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
nano 02-tu-turno.ldif 
exit
cd /ldif/
ls
nano 02-tu-turno.ldif 
ldapadd -x -c -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
exit
cd /ldif/
ls
nano 02-tu-turno.ldif 
ldapadd -x -c -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
ldapadd -x -c -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldapadd -x -c -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldapadd -x -c -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 01-ejemplo.ldif 
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
nano 02-tu-turno.ldif 
exit
nano 02-tu-turno.ldif 
cd /ldif/
nano 02-tu-turno.ldif 
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
ldapadd -x -c -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldapadd -x -c -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 01-ejemplo.ldif 
nano 01-ejemplo.ldif 
ldapadd -x -c -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=rrhh)" member
nano 02-tu-turno.ldif 
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=rrhh)" member
nano 02-tu-turno.ldif 
ldapadd -x -c -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
member: uid=eleon,ou=people,dc=securecorp,dc=local
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=rrhh)" member
nano 02-tu-turno.ldif 
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=rrhh)" member
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
ldapadd -x -c -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
nano 02-tu-turno.ldif 
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
ldapadd -x -c -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif
ldapadd -x -c -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif
exit
nano 02-tu-turno.ldif 
cd /ldif/
nano 02-tu-turno.ldif 
ldapadd -x -c -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
nano 02-tu-turno.ldif 
nano 02-tu-turno.ldif 
ldapadd -x -c -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 01-ejemplo.ldif 
ldapadd -x - -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=rrhh)" member
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
exit
cd ldif
cd /ldif
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
nano 02-tu-turno.ldif 
exit
