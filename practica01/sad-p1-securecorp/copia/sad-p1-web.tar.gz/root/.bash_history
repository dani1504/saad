kinit dgonzalez
klist
exit
kinit dgonzalez
exit
