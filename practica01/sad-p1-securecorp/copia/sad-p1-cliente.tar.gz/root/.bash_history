nano /etc/ldap/ldap.conf
ldappasswd -x -H ldaps:// -D "cn=admin,dc=securecorp,dc=local" -w SecureCorp2026 -s 'Lucia2026' "uid=lromero,ou=people,dc=securecorp,dc=local"
exit
kinit lromero
klisty+
klist
exit
kinit dgonzalez
kinit mtorres
exit
kvno 
kvno host/web.securecorp.local
exit
kvno host/web.securecorp.local
klist
exit
klist
kdestroy
klist
kvno host/web.securecorp.local
kinit dgonzalez
kinit dgonzalez
kvno host/web.securecorp.local
exit
openssl x509 -in ca.crt -noout -subject -issuer
exit
