nano /etc/ldap/ldap.conf
ldappasswd -x -H ldaps:// -D "cn=admin,dc=securecorp,dc=local" -w SecureCorp2026 -s 'Lucia2026' "uid=lromero,ou=people,dc=securecorp,dc=local"
exit
kinit lromero
klisty+
klist
exit
kinit dgonzalez
kinit mtorres
exit
kvno 
kvno host/web.securecorp.local
exit
kvno host/web.securecorp.local
klist
exit
klist
kdestroy
klist
kvno host/web.securecorp.local
kinit dgonzalez
kinit dgonzalez
kvno host/web.securecorp.local
exit
openssl x509 -in ca.crt -noout -subject -issuer
exit
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
exit
ldapadd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif
exit
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=eleon,ou=people,dc=securecorp,dc=local" -w 'Elena2026'
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(cn=sistemas)" uid
exit
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=eleon,dc=securecorp,dc=local" "(cn=sistemas)" uid
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" uid
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)"
exit
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid cn
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(cn=sistemas)" uid cn
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(cn=sistemas)" uid
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(cn=sistemas)" member
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=group,dc=securecorp,dc=local" "(cn=sistemas)" member
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
cd /ldif/
ldapadd -x -H ldap://ldaps.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldapadd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldapadd -c -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldapadd -c -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Elena2026' "uid=eleon,ou=people,dc=securecorp,dc=local"
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=eleon,ou=people,dc=securecorp,dc=local" -w 'Elena2026'
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" member
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
exit
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=eleon,ou=people,dc=securecorp,dc=local" -w 'Elena2026'
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
exit
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=eleon,ou=people,dc=securecorp,dc=local" -w 'Elena2026'
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "()" member
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid cn
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid cn
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid cn
exit
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid cn
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid cn
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=rrhh)" uid
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=rrhh)" member
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
ldapadd -c -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
cd /ldif/
ldapadd -c -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
exit
ldapadd -c -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
cd /ldif/
ldapadd -c -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 01-ejemplo.ldif 
ldapadd -c -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=rrhh)" 
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=eleon,ou=people,dc=securecorp,dc=local" -w 'Elena2026'
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" cn
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
nano 02-tu-turno.ldif 
ldapadd -c -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=eleon,ou=people,dc=securecorp,dc=local" -w 'Elena2026'
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
ldapadd -c -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Elena2026' "uid=eleon,ou=people,dc=securecorp,dc=local"
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
ldapsearch -x -LLL -H ldaps://Ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
exit
cd /ldif/
ldapadd -c -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldapadd -c -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 01-ejemplo.ldif 
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Elena2026' "uid=eleon,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Elena2026' "uid=eleon,ou=people,dc=securecorp,dc=local"
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=eleon,ou=people,dc=securecorp,dc=local" -w 'Elena2026'
ldapsearch -x -LLL -H ldaps://Ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
ldapadd -c -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 01-ejemplo.ldif 
cd /ldif/
nano 01-ejemplo.ldif 
nano 02-tu-turno.ldif 
ldapadd -c -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 01-ejemplo.ldif 
ldapadd -c -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 01-ejemplo.ldif 
ldapadd -c -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldapsearch -x -LLL -H ldaps://Ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
nano 02-tu-turno.ldif 
ldapsearch -x -LLL -H ldaps://Ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
ldapsearch -x -LLL -H ldaps://Ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Elena2026' "uid=eleon,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Elena2026' "uid=eleon,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Elena2026' "uid=eleon,ou=people,dlocal"
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Elena2026' "uid=eleon,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Elena2026' "uid=eleon,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Elena2026' "uid=eleon,ou=people,dc=securecorp,dc=local"
ldapsearch -x -LLL -H ldaps://Ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=eleon,ou=people,dc=securecorp,dc=local" -w 'Elena2026'
nano 02-tu-turno.ldif 
ldapadd -c -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldapsearch -x -LLL -H ldaps://Ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
ldapsearch -x -LLL -H ldap://ldaps.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
nao 02-tu-turno.ldif 
nano 02-tu-turno.ldif 
ldapadd -c -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldapadd -c -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 01-ejemplo.ldif 
ldapadd -c -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Elena2026' "uid=eleon,ou=people,dc=securecorp,dc=local"
ldapsearch -x -LLL -H ldaps://Ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
nano 02-tu-turno.ldif 
exit
cd /ldif/
ldapadd -c -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 01-ejemplo.ldif 
ldapadd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 01-ejemplo.ldif 
ldapadd -c -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldapsearch -x -LLL -H ldaps://Ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
ldapsearch -x -LLL -H ldaps://Ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
ldapadd -c -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldapadd-x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldapadd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldapsearch -x -LLL -H ldaps://Ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
nano 02-tu-turno.ldif 
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Elena2026' "uid=eleon,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Elena2026' "uid=eleon,ou=people,dc=securecorp,dc=local"
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=eleon,ou=people,dc=securecorp,dc=local"
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=eleon,ou=people,dc=securecorp,dc=local" -w 'Elena2026'
ldapsearch -x -LLL -H ldaps://Ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
ldapadd -c -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldapsearch -x -LLL -H ldaps://Ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=rrhh)" member
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=rrhh)" member
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistema)" member
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)" member
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=eleon,ou=people,dc=securecorp,dc=local" -w 'Elena2026'
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=sistemas)"
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=eleon,ou=people,dc=securecorp,dc=local" -w 'Elena2026'
exit
